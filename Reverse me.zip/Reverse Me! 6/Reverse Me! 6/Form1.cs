﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Reverse_Me__6
{
    public partial class Form1 : Form
    {

        string duke;
        string us_name = System.Environment.UserName.ToString();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            

            string unique1 = RandomString(4);
            string unique2 = RandomString(6);

            if (File.Exists("C:/Temp/testvalue.txt"))
            {
                File.Delete("C:/Temp/testvalue.txt");
                File.Create("C:/Temp/testvalue.txt").Close();
                File.WriteAllText("C:/Temp/testvalue.txt", unique1);

            }
            else
            {
                File.Create("C:/Temp/testvalue.txt").Close();
                File.WriteAllText(@"C:/Temp/testvalue.txt", unique1);
            }


            if (File.Exists("C:/Temp/rundll_tmp.TEMP"))
            {
                File.Delete("C:/Temp/rundll_tmp.TEMP");
                File.Create("C:/Temp/rundll_tmp.TEMP").Close();
                File.WriteAllText(@"C:/Temp/rundll_tmp.TEMP", unique2);

            }
            else
            {
                File.Create("C:/Temp/rundll_tmp.TEMP").Close();
                File.WriteAllText(@"C:/Temp/rundll_tmp.TEMP", unique2);
            }
            

        }


        public static string doit(string s)
        {
            char[] c = s.ToCharArray();
            Array.Reverse(c);
            return new string(c);
        }

        public static string RandomString(int length)
        {
            const string cs = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var r = new Random();
            return new string(Enumerable.Repeat(cs, length)
              .Select(s => s[r.Next(s.Length)]).ToArray());
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://camedcomputing.wordpress.com");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string a;
                string b;

                using (StreamReader sr = new StreamReader("C:/Temp/testvalue.txt"))
                {
                    a = sr.ReadToEnd();
                }
                using (StreamReader sr = new StreamReader("C:/Temp/rundll_tmp.TEMP"))
                {
                    b = sr.ReadToEnd();
                }

                string gotcha = doit(us_name);
                duke = a + gotcha + b;
                if (textBox1.Text == duke)
                {
                    MessageBox.Show("Correct!");
                }
                else
                {
                    MessageBox.Show("Wrong Password");
                }

            }
            catch
            {

            }
        }



    }
}
