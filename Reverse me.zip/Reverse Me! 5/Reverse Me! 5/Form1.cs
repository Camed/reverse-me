﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reverse_Me__5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button2.Enabled = true;
            if(button1.Enabled == true)
            {
                MessageBox.Show("Password is 78asC");
                if(textBox1.Text =="78asC")
                {
                    MessageBox.Show("Great! You passed challange!");
                   
                }
                else
                {
                    MessageBox.Show("Wait, what?");
                }
            }
        }


        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://camedcomputing.wordpress.com");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.Enabled = true;
            button2.Enabled = false;
            if (button2.Enabled == true)
            {
                MessageBox.Show("Password is 78asC");
                if (textBox1.Text == "78asC")
                {
                    MessageBox.Show("Great! You passed challange!");

                }
                else
                {
                    MessageBox.Show("Wait, what?");
                }
            }
        }
    }
}
