﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reverse_Me__3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public string getMD5(string i)
        {
            MD5 md5 = System.Security.Cryptography.MD5.Create();

            byte[] ibyte = System.Text.Encoding.ASCII.GetBytes(i);
            byte[] iscontainingbytes = md5.ComputeHash(ibyte);


            StringBuilder strBuilder1 = new StringBuilder();

            for (int a = 0; a < iscontainingbytes.Length; a++)
            {

                strBuilder1.Append(iscontainingbytes[a].ToString("X2"));

            }

            return strBuilder1.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string first = getMD5(textBox1.Text);
            if (first == "22DB96BB26EEAF15E68B828A1361C132")
            {
                MessageBox.Show("Correct password!", "Great job!");
            }
            else
            {
                MessageBox.Show("Incorrect password.", "Sorry");
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://camedcomputing.wordpress.com");
        }
    }
}