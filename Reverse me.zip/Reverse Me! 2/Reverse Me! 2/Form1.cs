﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reverse_Me__2
{
    public partial class Form1 : Form

    {
        
    public string buff = null;
    public string string1 = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string password = "damn_password123";
            int shift;
            Shift OBSHIFT = new Shift();
            shift = -3;
            string1 = (OBSHIFT.Cshift(password, shift)).ToString();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://camedcomputing.wordpress.com");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            buff = textBox1.Text;
     
            if(buff == string1)
            {

                MessageBox.Show("Great, you passed second level!", "Great Job!");
                Application.Exit();

            }
            else
            {
                MessageBox.Show("Wrong Password!", "Wrong Password!");
            }


        }
    }

    class Shift
    {
        public string Cshift(string str, int shift)
        {
            string UserOutput = null;
            char[] A = null;
            A = str.ToCharArray();
            int temp;

            for (int i = 0; i < str.Length; i++)
            {
                temp = (int)(A[i] + shift);
                UserOutput += (char)temp;
            }
            return UserOutput;
        }
    }

}
