﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reverse_Me__4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://camedcomputing.wordpress.com");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient client = new WebClient();
            Stream stream = client.OpenRead(Properties.Resources.funcuri);
            StreamReader reader = new StreamReader(stream);
            String content = reader.ReadToEnd();

            if(textBox1.Text == content){
                MessageBox.Show("Great Job!","Password was found!");
            }
            else
            {
                MessageBox.Show("Incorrect password.", "Wrong password");
            }

        }
    }
}
