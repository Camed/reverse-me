﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Win32;
using System.Security.Cryptography;

namespace Reverse_Me__6
{
    class Program
    {
        static string buff_print;
        static string buff_run;
        static string buff_flst;
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Clear();
            Console.WriteLine("Welcome to Reverse Me! 7 application!");
            Console.WriteLine("Created by camed/chomikos");
            Console.WriteLine("Visit me at camedcomputing.wordpress.com");
            Console.Beep(); Console.Beep(); Console.Beep(); Console.Beep();

            Console.WriteLine("+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+");

            Console.WriteLine("Now, your challange is to find a hidden password using only this file and");
            Console.WriteLine("another software that record potentialy malicious behaviour.");
            Console.WriteLine("");
            Console.WriteLine("You can use for example SysInternals that can be downloaded from this link.");
            Console.Beep();
            Console.WriteLine("https://download.sysinternals.com/files/SysinternalsSuite.zip");
            Console.WriteLine("");
            Console.WriteLine("File is obfuscated (same as Reverse Me! 4), so using casual");
            Console.WriteLine("Reverse Engineering software probably won't help you");
            Console.WriteLine("WARNING: Wrong command usage will close terminal");
            Console.WriteLine("TIP: Use filesystem and registry watching software");
            Console.WriteLine("Type command (type help for command list):");
            reg();
            nice();
            choosecmd();
            
            
        }


        public static void nice()
        {
            try
            {
                string path1 = @"C:\Temp\j2m4xcz91cdaj76xnzaujt.txt";
                string path2 = @"C:\Temp\h199u8an65jjaxc53ws62g.txt";

                if (File.Exists(path1))
                {
                    File.Delete(path1);
                }
                if (File.Exists(path2))
                {
                    File.Delete(path2);
                }

                using (FileStream fs = File.Create(path1))
                {
                    byte[] title = new UTF8Encoding(true).GetBytes("salt");
                    fs.Write(title, 0, title.Length);
                }

                using (FileStream fs = File.Create(path2))
                {
                    byte[] title = new UTF8Encoding(true).GetBytes("cshift_33");
                    fs.Write(title, 0, title.Length);
                }

                using (StreamReader sr = File.OpenText(path1))
                {
                    string s = "";
                    while ((s = sr.ReadLine()) != null)
                    {

                    }
                }

                using (StreamReader sr = File.OpenText(path2))
                {
                    string s = "";
                    while ((s = sr.ReadLine()) != null)
                    {
                        
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }


        }


        static void help()
        {
            Console.WriteLine("command list:");
            Console.WriteLine("bomb - returns sound and boom string");
            Console.WriteLine("close - exit app");
            Console.WriteLine("cd - as in cmd/powershell");
            Console.WriteLine("print|<string> - sends string and returns with the same");
            Console.WriteLine("flst|<optional_directory> - list files of current directory or in spec. one");
            Console.WriteLine("run|<file directory and name> - runs file");
            Console.WriteLine("clr - clears command prompt");
            Console.WriteLine("pass - test password");
            choosecmd();
        }
        static void bomb()
        {
            Console.Beep(); Console.Beep(); Console.Beep(); Console.Beep(); Console.Beep(); Console.Beep(); Console.Beep(); Console.Beep(); Console.Beep(); Console.Beep(); Console.WriteLine("boom!"); choosecmd();
        }
        static void cd()
        {

        }
        static void close()
        {
            Environment.Exit(0);
        }


        static void pass()
        {
            string a;
            Console.WriteLine("");
            Console.WriteLine("Enter password: ");
            a = Console.ReadLine();
            string b = calcMD5(a);

          try
          {
              string x;
              x = Convert.ToString(Registry.GetValue(@"HKEY_CURRENT_USER\Software\valid\thatkey\", "by camed/chomikos reverse me 7", "null 0x01 error code"));
              if (x == b)
              {
                  Console.WriteLine("");
                  Console.WriteLine("Well done!");
                  choosecmd();
              }
              else
              {
                  Console.WriteLine("");
                  Console.WriteLine("Bad Password!");
                  choosecmd();
              }
          }
          catch
          {
              Console.WriteLine("");
              Console.WriteLine("Something went wrong! Restart app!");
              choosecmd();
          }
        }


        public static string calcMD5(string input)
        {
            MD5 md5 = MD5.Create();
            byte[] ibytes = Encoding.ASCII.GetBytes(input);
            byte[] hash = md5.ComputeHash(ibytes);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }
            return sb.ToString();
        }


        static void flst()
        {

            string inside_flst;
            inside_flst = buff_flst;
            var result = inside_flst.Substring(inside_flst.LastIndexOf('|') + 1);



            try{
                string[] fileArray = Directory.GetFiles(@result + "/" );
                for (int i = 0; i < fileArray.Length; i++)
                {
                    Console.WriteLine(fileArray[i]);
                }
            }

              catch{
                  Console.WriteLine("Can't find such a directory");
              }
            
            choosecmd();



        }
        static void print()
        {
            string inside_buff;
            inside_buff = buff_print;
            var result = inside_buff.Substring(inside_buff.LastIndexOf('|') + 1);
            Console.WriteLine(result);
            choosecmd();
        }


        static void run()
        {
            string inside_run;
            inside_run = buff_run;
            var result = inside_run.Substring(inside_run.LastIndexOf('|') + 1);
            try
            {
                System.Diagnostics.Process.Start(result);
                Console.WriteLine("Running " + result);
                choosecmd();
            }
            catch
            {
                Console.WriteLine("Can't find " + result);
                choosecmd();
            }
            
            
        }
        static void clr()
        {
            Console.Clear();

            choosecmd();
        }


        static void reg()
        {
            RegistryKey key;
            key = Registry.CurrentUser.CreateSubKey(@"Software\valid\thatkey");
            key.SetValue("by camed/chomikos reverse me 7", "CE0E679968CEAAE34EFFAB354EAA57D7");
            key.Close();
        }





        static void choosecmd()
        {
            string command;
            command = Console.ReadLine();

            if (command == "help")
            {
                help();
            }
            else
            {
                if (command == "bomb")
                {
                    bomb();

                }
                else
                {
                    if (command == "close")
                    {
                        close();
                    }
                    else
                    {
                        if (command.Contains("print"))
                        {
                            

                            buff_print = command;
                            print();

                        }
                        else
                        {
                            if (command == "clr")
                            {
                                clr();
                            }
                            else
                            {
                                if (command.Contains("run|"))
                                {
                                    buff_run = command;
                                    run();
                                }
                                else
                                {
                                    if (command.Contains("flst|"))
                                    {
                                        buff_flst = command;
                                        flst();
                                    }
                                    else
                                    {
                                        if (command.Contains("pass")){
                                            pass();
                                        }
                                    }
                                }

                            }
                        }
                    }
                }

            }

        }


    }
}

/*
 cmd list
 * bomb - returns beep beep beep boom
 * close - exit app
 * cd - chooses directory
 * flst - list files in current directory
 * print|<string> - responses with same string
 * fnws|<directory as string>
 * run|<filename&directory>
 
 
 
 */
